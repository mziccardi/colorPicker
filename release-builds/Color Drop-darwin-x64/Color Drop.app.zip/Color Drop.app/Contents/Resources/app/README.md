

# colorDrop

ColorDrop is an electron menubar app that allows a user to get the hex value of any pixel on their screen. It is built using a classic TDD red green refactor model.

## Let's begin
clone down, <code>npm i</code> then <code>electron .</code>

## Development 

## Testing

